### Quiz 3 - predict next word ###

### Load all needed packages
library(quanteda)
library(tm)
library(RWeka)
library(ngram)
library(dplyr)

### Load and view dataset
en_us_tw <- readLines("~/data/en_US.twitter.txt", skipNul = TRUE) 
en_us_blog <- readLines("~/data/en_US.blogs.txt", skipNul = TRUE)
en_us_news <- readLines("~/data/en_US.news.txt", skipNul = TRUE)

### Tokenization - clean text
tokenmaker <- function(x) {
  corpus <- VCorpus(VectorSource(x))
  corpus <- tm_map(corpus, removePunctuation)
  corpus <- tm_map(corpus, removeNumbers)
  corpus <- tm_map(corpus, stripWhitespace)
  corpus <- tm_map(corpus, content_transformer(tolower))
  corpus <- tm_map(corpus, PlainTextDocument)
  # corpus <- tm_map(corpus, stemDocument, language = "en") 
  # corpus <- tm_map(corpus, removeWords, stopwords("english"))
  # corpus <- Corpus(VectorSource(corpus))
}  

### Word frequency (unigrams)
unigrams <- function(x) {
  unigrams <- TermDocumentMatrix(x) %>%
    as.matrix() %>%
    as.data.frame() %>%
    rowSums() %>%
    sort(decreasing=TRUE)
  return(data.frame(Word=names(unigrams), Count=unigrams, row.names=(1:length(unigrams))))
  ##return(data.frame(Word=names(unigrams), Count=unigrams, row.names=(1:length(unigrams)))[1:20,])
}

### Tokenization - Bigrams
bigramtoken <- function(x) NGramTokenizer(x, Weka_control(min = 2, max = 2))

bigrams <- function(x) {
  bigrams <- TermDocumentMatrix(x, control = list(tokenize = bigramtoken)) %>%
    as.matrix() %>%
    as.data.frame() %>%
    rowSums() %>%
    sort(decreasing=TRUE)
  return(data.frame(Word=names(bigrams), Count=bigrams, row.names=(1:length(bigrams))))
}

### Tokenization - Trigrams
trigramtoken <- function(x) NGramTokenizer(x, Weka_control(min = 3, max = 3))

trigrams <- function(x) {
  trigrams <- TermDocumentMatrix(x, control = list(tokenize = trigramtoken)) %>%
    as.matrix() %>%
    as.data.frame() %>%
    rowSums() %>%
    sort(decreasing=TRUE)
  return(data.frame(Word=names(trigrams), Count=trigrams, row.names=(1:length(trigrams))))
}

### Tokenization - 4-grams
forthgramtoken <- function(x) NGramTokenizer(x, Weka_control(min = 4, max = 4))

forthgrams <- function(x) {
  forthgrams <- TermDocumentMatrix(x, control = list(tokenize = forthgramtoken)) %>%
    as.matrix() %>%
    as.data.frame() %>%
    rowSums() %>%
    sort(decreasing=TRUE)
  return(data.frame(Word=names(forthgrams), Count=forthgrams, row.names=(1:length(forthgrams))))
}

### Due to machine's computation power and memory, create a function to select all rows from Blogs, News and Twitters which contain 
### the previous 3 words before the upcoming word that is being predicted.

previoustext <- "during the"   ### pls edit here

tw <- en_us_tw[grepl(previoustext, en_us_tw, ignore.case=TRUE)]
blog <- en_us_blog[grepl(previoustext, en_us_blog, ignore.case=TRUE)]
news <- en_us_news[grepl(previoustext, en_us_news, ignore.case=TRUE)]
alltext <- c(tw, blog, news)
rm(tw, blog, news)

### Choose the most high frequency word based on: if number of words of previous text is n, then search from (n+1)grams until unigrams. 
ctext <- tokenmaker(alltext)
forthfreq <- forthgrams(ctext); head(forthfreq[grepl(previoustext, forthfreq[,"Word"]),],30)
trifreq <- trigrams(ctext); head(trifreq[grepl(previoustext, trifreq[,"Word"]),],30)
head(trigrams(ctext),20)
head(bigrams(ctext),20)
head(unigrams(ctext),20)

