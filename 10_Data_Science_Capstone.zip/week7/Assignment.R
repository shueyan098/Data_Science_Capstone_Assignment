### Assignment - predict next word ###

### Load all needed packages
library(tm)
library(RWeka)
library(ngram)
library(dplyr)
library(stringr)

### Load and view dataset
en_us_tw <- readLines("~/data/en_US.twitter.txt", skipNul = TRUE) 
en_us_blog <- readLines("~/data/en_US.blogs.txt", skipNul = TRUE)
en_us_news <- readLines("~/data/en_US.news.txt", skipNul = TRUE)

saveRDS(en_us_news, file = "~/data/en_us_news.RDS", compress = "xz")
saveRDS(en_us_blog, file = "~/data/en_us_blog.RDS", compress = "xz")
saveRDS(en_us_tw, file = "~/data/en_us_tw.RDS", compress = "xz")

rm(en_us_tw, en_us_blog, en_us_news)

### Tokenization - clean text
tokenmaker <- function(x) {
  corpus <- VCorpus(VectorSource(x))
  corpus <- tm_map(corpus, removePunctuation)
  corpus <- tm_map(corpus, removeNumbers)
  corpus <- tm_map(corpus, stripWhitespace)
  corpus <- tm_map(corpus, content_transformer(tolower))
  corpus <- tm_map(corpus, PlainTextDocument)
  # corpus <- tm_map(corpus, stemDocument, language = "en") 
  # corpus <- tm_map(corpus, removeWords, stopwords("english"))
}  

### Tokenization - Bigrams
bigramtoken <- function(x) NGramTokenizer(x, Weka_control(min = 2, max = 2))

bigrams <- function(x) {
  bigrams <- TermDocumentMatrix(x, control = list(tokenize = bigramtoken)) %>%
    as.matrix() %>%
    as.data.frame() %>%
    rowSums() %>%
    sort(decreasing=TRUE)
  return(data.frame(Word=names(bigrams), Count=bigrams, row.names=(1:length(bigrams))))
}

### Tokenization - Trigrams
trigramtoken <- function(x) NGramTokenizer(x, Weka_control(min = 3, max = 3))

trigrams <- function(x) {
  trigrams <- TermDocumentMatrix(x, control = list(tokenize = trigramtoken)) %>%
    as.matrix() %>%
    as.data.frame() %>%
    rowSums() %>%
    sort(decreasing=TRUE)
  return(data.frame(Word=names(trigrams), Count=trigrams, row.names=(1:length(trigrams))))
}

### Tokenization - 4-grams
forthgramtoken <- function(x) NGramTokenizer(x, Weka_control(min = 4, max = 4))

forthgrams <- function(x) {
  forthgrams <- TermDocumentMatrix(x, control = list(tokenize = forthgramtoken)) %>%
    as.matrix() %>%
    as.data.frame() %>%
    rowSums() %>%
    sort(decreasing=TRUE)
  return(data.frame(Word=names(forthgrams), Count=forthgrams, row.names=(1:length(forthgrams))))
}

### Tokenization - 5-grams
fifthgramtoken <- function(x) NGramTokenizer(x, Weka_control(min = 5, max = 5))

forthgrams <- function(x) {
  fifthgrams <- TermDocumentMatrix(x, control = list(tokenize = fifthgramtoken)) %>%
    as.matrix() %>%
    as.data.frame() %>%
    rowSums() %>%
    sort(decreasing=TRUE)
  return(data.frame(Word=names(fifthgrams), Count=fifthgrams, row.names=(1:length(fifthgrams))))
}

### Due to machine's computation power and memory, create a function to select all rows from Blogs, News and Twitters which contain 
### the previous words before the upcoming word that is being predicted.

en_us_tw <- readRDS("~/data/en_us_tw.RDS")
en_us_blog <- readRDS("~/data/en_us_blog.RDS")
en_us_news <- readRDS("~/data/en_us_news.RDS")

### function to predict next word
nextword <- function(x){
  inputtextclean <- gsub("[^a-zA-Z ]+", "", x)
  inputtextclean <- gsub("( )( )+", " ", inputtextclean)
  inputtextclean <- gsub("^ ", "", inputtextclean)
  inputtextclean <- gsub(" $", "", inputtextclean)
  
  totalword <- wordcount(inputtextclean)
  m <- 4      ## m-grams
  max_loop <- 3    ## possible max loop to check all m-grams 
  cur_loop <- 1   ## initial loop
  
  while (cur_loop <= max_loop) {
    
    previoustext <- ifelse(m <= totalword, word(inputtextclean, -m+1 , -1), inputtextclean)
    
    tw <- en_us_tw[grepl(previoustext, en_us_tw, ignore.case=TRUE)]
    blog <- en_us_blog[grepl(previoustext, en_us_blog, ignore.case=TRUE)]
    news <- en_us_news[grepl(previoustext, en_us_news, ignore.case=TRUE)]
    alltext <- c(tw, blog, news)
    rm(tw, blog, news)
    
    if(length(alltext) == 0) {
      cur_loop <- cur_loop + 1
      m <- m-1
    } else {
      cur_loop <- 10
    }
  
  }  
  
  if(length(alltext) > 0) {
    ### Choose the most high frequency word based on: if number of words of previous text is n, then search from (n+1)grams until bigrams. 
    ctext <- tokenmaker(alltext)
    
    if (m == 4) {
      forthfreq <- forthgrams(ctext)
      return(word(as.character(head(forthfreq[startsWith(as.character(forthfreq$Word), previoustext),],1)$Word),-1))
    } 
    
    if (m == 3) {
      trifreq <- trigrams(ctext)
      return(word(as.character(head(trifreq[startsWith(as.character(trifreq$Word), previoustext),],1)$Word),-1))
    }
    
    if (m == 2) {
      bifreq <- bigrams(ctext)
      return(word(as.character(head(bifreq[startsWith(as.character(bifreq$Word), previoustext),],1)$Word),-1))
    }
  }
    
}

inputtext <- "babay i love you so"  ### input text here
nextword(inputtext)

