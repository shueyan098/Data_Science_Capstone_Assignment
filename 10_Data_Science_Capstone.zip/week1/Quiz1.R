en_us_tw <- readLines("~/data/en_US.twitter.txt")
en_us_blog <- readLines("~/data/en_US.blogs.txt")
en_us_news <- readLines("~/data/en_US.news.txt")

### 1
## The en_US.blogs.txt file is how many megabytes?
## 200


### 2
length(en_us_tw)
## 2360148

## Do wc -l en_US.twitter.txt at the prompt (or git bash on windows) or length(readLines("en_US.twitter.txt")) in R



### 3
max(nchar(en_us_tw))
max(nchar(en_us_blog))
max(nchar(en_us_news))

## 213
## 40835
## 5760

## Again a simple wc command suffices 
## wc -L *.txt  in the directory with the three files. Note, we had a small discrepancy between doing thin in R versus WC.



### 4
## In the en_US twitter data set, if you divide the number of lines where the word "love" (all lowercase) occurs 
## by the number of lines the word "hate" (all lowercase) occurs, about what do you get?

love <- length( en_us_tw[grep("love", en_us_tw)] )
hate <- length( en_us_tw[grep("hate", en_us_tw)] )
love/hate

## 4.108592 ~ 4

## grep"love"en_US.twitterwc???l??? and
## grep "hate" en_US.twitter | wc -l|   gives you the counts. Then you could divide in whatever.
## If you never want to leave the console, you can use bc (not present on gitbash in windows). 
## You could also read into R (readLines) and use character search.

## This worked on gitbash
## love=$(grep "love" en_US.twitter.txt | wc -l) | then
## hate=$(grep "hate" en_US.twitter.txt | wc -l) | then
## let m=love/hate then
## echo $m



### 5
## The one tweet in the en_US twitter data set that matches the word "biostats" says what?

en_us_tw[grep("biostats", en_us_tw)]
## [1] "i know how you feel.. i have biostats on tuesday and i have yet to study =/"

## coursera answer: grep -i "biostat" en_US.twitter.txt (note the -i doesn't matter since there's only one line ignoring case).



### 6
## How many tweets have the exact characters "A computer once beat me at chess, but it was no match for me at kickboxing". 
## (I.e. the line matches those characters exactly.)

length( en_us_tw[en_us_tw == "A computer once beat me at chess, but it was no match for me at kickboxing"] )
## 3
## coursera answer: grep -x "A computer once beat me at chess, but it was no match for me at kickboxing" en_US.twitter.txtwc???l|

